###

# number of iterations
N_times <- 20

# load auxiliary functions
source('../scripts/aux_functions.R', verbose = F)

# load data
df <- read.csv('../data/full-factorial-construction_Diaz-Colunga2024.csv')

# possible methods
methods <- c('LM', 'pairwise', 'reg_pairwise', 'FM', 'RF', 'gradient_boosting', 'GP', 'NN', 'control')

# run each method 20 times, see how they perform (quantify Q)
Q <- lapply(methods,
            FUN = function(m) {
              Q_m <- numeric(0)
              for (i in 1:N_times) {
                Q_m <- c(Q_m, getQ(df, method = m, training_fraction = 0.1))
              }
              return(Q_m)
            })
  
# structure data frame for plotting
Q <- data.frame(method = rep(methods, each = N_times),
                Q = unlist(Q))
Q$method <- factor(Q$method, levels = methods)

library(ggplot2)
ggplot(Q, aes(x = method, y = Q, color = method, fill = method)) +
  geom_violin(color = NA,
              alpha = 0.25) +
  geom_jitter(width = 0.1) +
  scale_y_continuous(name = 'Q',
                     limits = c(0,1)) +
  scale_color_manual(values = c(rep('black', length(methods) - 1), 'red')) +
  scale_fill_manual(values = c(rep('black', length(methods) - 1), 'red')) +
  theme_bw() +
  theme(aspect.ratio = 0.4,
        axis.title.x = element_blank(),
        axis.text.x = element_text(angle = 30,
                                   hjust = 1),
        legend.position = 'none')

