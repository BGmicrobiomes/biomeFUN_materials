import numpy as np
import os 
import pandas as pd
import numpy.linalg as linalg
from scipy.optimize import linprog
from scipy.linalg import null_space
import matplotlib.pyplot as plt
import cobra
from cobra.io import load_json_model, save_json_model
from cobra import Model, Reaction, Metabolite
from cobra.util.solver import set_objective

def metabolite_flux_summary(model, met_id, solution):
    """
    For a given metabolite and FBA solution, print net production/consumption
    by each reaction.

    Parameters:
    - model: COBRA model
    - met_id: metabolite ID (e.g., 'atp_c')
    - solution: a solution object from model.optimize()
    """
    try:
        met = model.metabolites.get_by_id(met_id)
    except KeyError:
        print(f"❌ Metabolite '{met_id}' not found in model.")
        return

    print(f"\n🔬 Net flux contribution for '{met_id}' ({met.name}):")

    producers = []
    consumers = []

    for rxn in met.reactions:
        coeff = rxn.metabolites[met]         # stoichiometry
        flux = solution.fluxes[rxn.id]       # actual flux value
        net = coeff * flux                   # net production/consumption

        if net > 0:
            producers.append((rxn.id, net))
        elif net < 0:
            consumers.append((rxn.id, net))

    # Sort by absolute value of net flux
    producers.sort(key=lambda x: abs(x[1]), reverse=True)
    consumers.sort(key=lambda x: abs(x[1]), reverse=True)

    print("\n✅ Produced by:")
    for rxn_id, net in producers:
        print(f"  {rxn_id:25s} → +{net:.3f} mmol/gDW/h")

    print("\n❌ Consumed by:")
    for rxn_id, net in consumers:
        print(f"  {rxn_id:25s} → {net:.3f} mmol/gDW/h")   

def model_from_matrix(
    S,                # (m x n) stoichiometric matrix; S[i,j] = coeff of metabolite i in reaction j
    met_ids,          # list[str] length m
    rxn_ids,          # list[str] length n
    lb=None,          # array-like length n (defaults to -1000)
    ub=None,          # array-like length n (defaults to  1000)
    obj_rxn_id=None,  # optional: set a single reaction as objective
    obj_lin=None,     # optional: linear objective coeffs (length n); ignored if obj_rxn_id given
    compartment="c",  # default compartment for metabolites
    model_id="from_S" # model name 
):
    S = np.asarray(S, dtype=float)
    m, n = S.shape
    assert len(met_ids) == m and len(rxn_ids) == n, "Dimension mismatch."

    if lb is None: lb = np.full(n, -1000.0)
    if ub is None: ub = np.full(n,  1000.0)

    mdl = Model(model_id)

    # Create metabolites
    mets = {mid: Metabolite(id=mid, compartment=compartment) for mid in met_ids}

    # Create reactions and add stoichiometry
    for j, rid in enumerate(rxn_ids):
        r = Reaction(id=rid)
        r.lower_bound = float(lb[j])
        r.upper_bound = float(ub[j])
        # Only pass non-zeros
        stoich = {mets[met_ids[i]]: float(S[i, j]) for i in range(m) if S[i, j] != 0.0}
        if stoich:
            r.add_metabolites(stoich)
        mdl.add_reactions([r])

    # Set objective (either single reaction or linear combination)
    if obj_rxn_id is not None:
        mdl.objective = mdl.reactions.get_by_id(obj_rxn_id)
        mdl.objective_direction = "max"
    elif obj_lin is not None:
        obj_lin = np.asarray(obj_lin, dtype=float)
        coeffs = {mdl.reactions.get_by_id(rxn_ids[j]): float(obj_lin[j]) for j in range(n) if obj_lin[j] != 0.0}
        set_objective(mdl, coeffs, additive=False)   # maximize by default

    save_json_model(mdl, model_id)
    return mdl

def add_enzyme_pool_constraint(
    model,
    pool_cap=0.8,                           # ENZ_PROD upper bound
    biomass_ids=("Biomass",),               # biomass rxn IDs to weight with w_biomass
    enzyme_id="enzyme_c",                   # pooled proteome metabolite
    enzyme_name="Enzyme pool",
    compartment="c",
    prod_rxn_id="ENZ_PROD",                 # enzyme production reaction
    w_biomass=0.37,                         # proteome cost per unit biomass flux
    w_default=0.003,                        # proteome cost per unit flux (other reactions)
    exclude_ids=("ENZ_PROD", "ACt2r", "H2Ot", "CO2t", "PIt2r", "O2t"),  # reactions to skip
    exclude_boundary=True                   # skip EX_* / boundary reactions
):
    """
    Add a lumped 'enzyme pool' constraint:
      ENZ_PROD: -> enzyme_c   (0 <= v <= pool_cap)
    and add enzyme usage to reactions:
      biomass_ids:      coeff = -w_biomass
      other reactions:  coeff = -w_default
    Skips boundary (EX_*) and reactions in exclude_ids.
    Idempotent: calling it again will set (not duplicate) the coefficients.
    """
    # 1) Ensure enzyme metabolite exists
    if enzyme_id in model.metabolites:
        enzyme = model.metabolites.get_by_id(enzyme_id)
    else:
        enzyme = Metabolite(enzyme_id, name=enzyme_name, compartment=compartment)
        model.add_metabolites([enzyme])

    # 2) Ensure ENZ_PROD exists and makes +1 enzyme_c with desired bounds
    if prod_rxn_id in model.reactions:
        enz_prod = model.reactions.get_by_id(prod_rxn_id)
    else:
        enz_prod = Reaction(prod_rxn_id, name="Enzyme production")
        model.add_reactions([enz_prod])

    enz_prod.lower_bound = 0.0
    enz_prod.upper_bound = float(pool_cap)

    # Set the enzyme stoichiometry in ENZ_PROD to exactly +1
    current = enz_prod.metabolites.get(enzyme, 0.0)
    delta = 1.0 - current
    if abs(delta) > 1e-12:
        enz_prod.add_metabolites({enzyme: delta})

    # Helper to *set* (not add twice) the enzyme coefficient in a reaction
    def _set_enzyme_coeff(rxn, target_coeff):
        cur = rxn.metabolites.get(enzyme, 0.0)
        delta = float(target_coeff) - cur
        if abs(delta) > 1e-12:
            rxn.add_metabolites({enzyme: delta})

    # 3) Add enzyme usage to reactions
    biomass_ids = set(biomass_ids)
    skip_ids = set(exclude_ids) | {prod_rxn_id}

    for rxn in model.reactions:
        if rxn.id in skip_ids:
            continue
        if exclude_boundary and rxn.id.startswith("EX_"):
            continue

        if rxn.id in biomass_ids:
            _set_enzyme_coeff(rxn, -abs(w_biomass))
        else:
            _set_enzyme_coeff(rxn, -abs(w_default))

    return enzyme, enz_prod  # handy if you want to inspect them later
